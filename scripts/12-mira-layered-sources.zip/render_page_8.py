from pathlib import Path
from PIL import Image,ImageDraw,ImageOps
import numpy as np,cv2,subprocess
ROOT=Path(__file__).resolve().parent;P=ROOT/'renders';D=P/'layers-v2';D.mkdir(parents=True,exist_ok=True);(P/'clips').mkdir(exist_ok=True)
W,H=1200,400;FW,FH=780,260
bg=ImageOps.mirror(Image.open(str(ROOT/'sources'/'mira-p8-layered-background.png')).convert('RGB').resize((FW,FH),Image.Resampling.LANCZOS));bg.save(D/'8-background.webp')
def sprite(name,path,size,pos):
 im=Image.open(path).convert('RGBA');im=im.crop(im.getchannel('A').point(lambda v:255 if v>80 else 0).getbbox());im=ImageOps.mirror(im);im.thumbnail(size,Image.Resampling.LANCZOS);out=Image.new('RGBA',(FW,FH));out.alpha_composite(im,pos);out.save(D/('8-'+name+'.png'));return out
mira=sprite('mira',str(ROOT/'sources'/'mira-p8-layered-mira.png'),(88,185),(481,33))
bit=sprite('bit',str(ROOT/'sources'/'mira-p8-layered-bit.png'),(111,147),(250,95))
star=sprite('star',str(ROOT/'sources'/'mira-p5-layered-star.png'),(70,70),(358,42))
smallstars=Image.new('RGBA',(FW,FH))
for i,pos in enumerate([(138,193),(206,181),(591,192),(640,183)]):smallstars.alpha_composite(sprite('smallstar'+str(i),str(ROOT/'sources'/'mira-p5-layered-star.png'),(15,15),pos))
smallstars.save(D/'8-smallstars.png')
paper=np.full((FH,FW,3),[246,239,224],np.float32);BA=np.array(bg).astype(np.float32)
rng=np.random.default_rng(34);noise=cv2.GaussianBlur(rng.random((FH,FW)).astype('float32'),(0,0),7);noise=(noise-noise.min())/(noise.max()-noise.min())
def smooth(t):t=np.clip(t,0,1);return t*t*(3-2*t)
objs=[]
for name,im,start in [('star',star,.2),('mira',mira,1.8),('bit',bit,3.3),('smallstars',smallstars,5.1)]:
 a=np.array(im);alpha=a[:,:,3].astype(np.float32)/255;rgb=a[:,:,:3].astype(np.float32)
 gray=cv2.cvtColor(a[:,:,:3],cv2.COLOR_RGB2GRAY);edge=cv2.Canny(gray,45,100);edge[alpha<.1]=0
 # Alpha silhouette makes a complete outline without rectangular sprite edges.
 border=cv2.Canny(a[:,:,3],50,120);edge=np.maximum(edge,border)
 contours=cv2.findContours(edge,cv2.RETR_LIST,cv2.CHAIN_APPROX_NONE)[0];paths=sorted(contours,key=lambda c:cv2.arcLength(c,False),reverse=True);objs.append((name,rgb,alpha,start,paths))
def frame(t):
 p=smooth((t-6.7)/2.0);wash=smooth((p*1.45-noise*.40)*2.4);C=paper*(1-wash[:,:,None])+BA*wash[:,:,None]
 for name,rgb,alpha,start,paths in objs:
  duration=1.4 if name in ('mira','bit','rocket') else .8;progress=smooth((t-start)/duration)
  rem=progress*sum(len(c) for c in paths);ink=np.zeros((FH,FW),np.uint8)
  for path in paths:
   if rem<1:break
   pts=path[:min(len(path),int(rem))];rem-=len(path)
   if len(pts)>1:cv2.polylines(ink,[pts],False,190,1,cv2.LINE_AA)
  color=smooth((t-start-duration*.75)/(2.1 if name in ('mira','bit','rocket') else 1.2))
  paint=smooth((color*1.45-noise*.40)*2.4)*alpha
  ia=ink.astype(np.float32)/255*(1-color)*.7
  C=C*(1-ia[:,:,None])+np.array([77,63,72])*ia[:,:,None]
  C=C*(1-paint[:,:,None])+rgb*paint[:,:,None]
 # Star light follows the separate drawing, never replaces the star sprite.
 yy,xx=np.indices((FH,FW));glow=np.exp(-((xx-393)**2+(yy-76)**2)/(2*66**2))*.42*smooth((t-6.6)/1.7)
 C=C*(1-glow[:,:,None])+np.array([255,232,159])*glow[:,:,None]
 sa=np.array(star);al=sa[:,:,3].astype(np.float32)/255*smooth((t-.8)/2);C=C*(1-al[:,:,None])+sa[:,:,:3]*al[:,:,None]
 out=Image.new('RGB',(W,H),'#f6efe0');d=ImageDraw.Draw(out);d.rectangle((0,0,7,H),fill='#ede4d1');d.line((780,0,780,H),fill='#cfc1a6',width=3);d.line((791,12,791,H-12),fill='#e4d7bf');out.paste(Image.fromarray(C.clip(0,255).astype(np.uint8)),(0,70));return out
out=P/'clips/8-layered-v1.mp4';proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1200x400','-r','12','-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for k in range(132):
 im=frame(k/12)
 if k in (12,24,48,72,90,126):im.save(str(ROOT/'renders'/'mira-p8-layered-%03d.png')%k)
 proc.stdin.write(im.tobytes())
proc.stdin.close();assert proc.wait()==0
frame(10.9).save(P/'clips/8-layered-poster.webp',quality=92)
cs=Image.new('RGB',(1200,720),'white')
for i,k in enumerate((12,24,48,72,90,126)):
 im=Image.open(str(ROOT/'renders'/'mira-p8-layered-%03d.png')%k);im.thumbnail((600,200));cs.paste(im,((i%2)*600,(i//2)*240));ImageDraw.Draw(cs).text(((i%2)*600+8,(i//2)*240+205),str(k/12)+'s',fill='black')
cs.save(str(ROOT/'renders'/'mira-p8-layered-contact.png'));print(out,out.stat().st_size)
