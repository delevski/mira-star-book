from pathlib import Path
from PIL import Image,ImageDraw,ImageOps
import numpy as np,cv2,subprocess
ROOT=Path(__file__).resolve().parent;P=ROOT/'renders';D=P/'layers-v2';D.mkdir(parents=True,exist_ok=True);(P/'clips').mkdir(exist_ok=True)
W,H=1200,400;FW,FH=780,260
bg=ImageOps.mirror(Image.open(str(ROOT/'sources'/'mira-p4-layered-background.png')).convert('RGB').resize((FW,FH),Image.Resampling.LANCZOS));bg.save(D/'4-background.webp')
r=Image.open(str(ROOT/'sources'/'mira-p4-layered-rocket.png')).convert('RGBA');r=r.crop(r.getchannel('A').getbbox());r=ImageOps.mirror(r);r.thumbnail((151,176),Image.Resampling.LANCZOS)
rocket=Image.new('RGBA',(FW,FH));rocket.alpha_composite(r,(259,18));rocket.save(D/'4-rocket.png')
m=Image.open(str(ROOT/'sources'/'mira-p4-layered-moon.png')).convert('RGBA');m=m.crop(m.getchannel('A').getbbox());m.thumbnail((42,42),Image.Resampling.LANCZOS)
moon=Image.new('RGBA',(FW,FH));moon.alpha_composite(m,(79,31));moon.save(D/'4-moon.png')
stars=Image.new('RGBA',(FW,FH));sd=ImageDraw.Draw(stars)
for x,y,s in [(146,45,2),(174,100,1),(70,121,1),(221,124,1),(444,94,1),(502,28,1),(559,70,2),(657,17,1),(692,107,1),(748,52,1),(395,31,1)]:
 sd.line((x-s,y,x+s,y),fill=(255,240,208,170),width=1);sd.line((x,y-s,x,y+s),fill=(255,240,208,170),width=1)
stars.save(D/'4-stars.png')
paper=np.full((FH,FW,3),[246,239,224],np.float32);BA=np.array(bg).astype(np.float32)
rng=np.random.default_rng(34);noise=cv2.GaussianBlur(rng.random((FH,FW)).astype('float32'),(0,0),7);noise=(noise-noise.min())/(noise.max()-noise.min())
def smooth(t):t=np.clip(t,0,1);return t*t*(3-2*t)
objs=[]
for name,im,start in [('moon',moon,.4),('rocket',rocket,1.6),('stars',stars,5.9)]:
 a=np.array(im);alpha=a[:,:,3].astype(np.float32)/255;rgb=a[:,:,:3].astype(np.float32)
 gray=cv2.cvtColor(a[:,:,:3],cv2.COLOR_RGB2GRAY);edge=cv2.Canny(gray,45,100);edge[alpha<.1]=0
 # Alpha silhouette makes a complete outline without rectangular sprite edges.
 border=cv2.Canny(a[:,:,3],50,120);edge=np.maximum(edge,border)
 contours=cv2.findContours(edge,cv2.RETR_LIST,cv2.CHAIN_APPROX_NONE)[0];paths=sorted(contours,key=lambda c:cv2.arcLength(c,False),reverse=True);objs.append((name,rgb,alpha,start,paths))
def frame(t):
 p=smooth((t-6.1)/2.4);wash=smooth((p*1.45-noise*.40)*2.4);C=paper*(1-wash[:,:,None])+BA*wash[:,:,None]
 for name,rgb,alpha,start,paths in objs:
  duration=1.7 if name=='rocket' else .8;progress=smooth((t-start)/duration)
  rem=progress*sum(len(c) for c in paths);ink=np.zeros((FH,FW),np.uint8)
  for path in paths:
   if rem<1:break
   pts=path[:min(len(path),int(rem))];rem-=len(path)
   if len(pts)>1:cv2.polylines(ink,[pts],False,190,1,cv2.LINE_AA)
  color=smooth((t-start-duration*.75)/(2.8 if name=='rocket' else 1.2))
  paint=smooth((color*1.45-noise*.40)*2.4)*alpha
  ia=ink.astype(np.float32)/255*(1-color)*.7
  C=C*(1-ia[:,:,None])+np.array([77,63,72])*ia[:,:,None]
  C=C*(1-paint[:,:,None])+rgb*paint[:,:,None]
 out=Image.new('RGB',(W,H),'#f6efe0');d=ImageDraw.Draw(out);d.rectangle((0,0,7,H),fill='#ede4d1');d.line((780,0,780,H),fill='#cfc1a6',width=3);d.line((791,12,791,H-12),fill='#e4d7bf');out.paste(Image.fromarray(C.clip(0,255).astype(np.uint8)),(0,70));return out
out=P/'clips/4-layered-v1.mp4';proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1200x400','-r','12','-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
for k in range(132):
 im=frame(k/12)
 if k in (12,24,48,72,90,126):im.save(str(ROOT/'renders'/'mira-p4-layered-%03d.png')%k)
 proc.stdin.write(im.tobytes())
proc.stdin.close();assert proc.wait()==0
frame(10.9).save(P/'clips/4-layered-poster.webp',quality=92)
cs=Image.new('RGB',(1200,720),'white')
for i,k in enumerate((12,24,48,72,90,126)):
 im=Image.open(str(ROOT/'renders'/'mira-p4-layered-%03d.png')%k);im.thumbnail((600,200));cs.paste(im,((i%2)*600,(i//2)*240));ImageDraw.Draw(cs).text(((i%2)*600+8,(i//2)*240+205),str(k/12)+'s',fill='black')
cs.save(str(ROOT/'renders'/'mira-p4-layered-contact.png'));print(out,out.stat().st_size)
