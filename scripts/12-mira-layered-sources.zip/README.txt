Mira layered illustration sources for pages 4, 5, 6, 8, 9.
Requires Python 3, Pillow, NumPy, OpenCV and ffmpeg on PATH.
Run each render_page_N.py. Output is in renders/clips.
Original story words and narration remain in the existing book manifest.
The production filenames have upload prefixes; see src/App.tsx for routes.
